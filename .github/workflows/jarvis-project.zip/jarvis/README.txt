BUILD: open this folder in Android Studio (needs internet), wait for Gradle sync, then Build > Build APK(s).
Install the APK on the phone, open Jarvis, allow permissions, then in Settings > Accessibility switch on "Jarvis".

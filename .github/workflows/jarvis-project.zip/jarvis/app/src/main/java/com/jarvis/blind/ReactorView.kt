package com.jarvis.blind
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.*
class ReactorView(c: Context) : View(c) {
  var boot = 0f; var mode = 0; var level = 0f
  private var t = 0f; private var ba: ValueAnimator? = null
  private val p = Paint(Paint.ANTI_ALIAS_FLAG)
  init { setLayerType(LAYER_TYPE_SOFTWARE, null)
    ValueAnimator.ofFloat(0f, 1f).apply { duration = 1000; repeatCount = -1; interpolator = LinearInterpolator(); addUpdateListener { t += 0.016f; invalidate() }; start() } }
  private fun go(to: Float, ms: Long) { ba?.cancel(); ba = ValueAnimator.ofFloat(boot, to).apply { duration = ms; addUpdateListener { boot = it.animatedValue as Float }; start() } }
  fun wake() = go(1f, 2400); fun sleep() = go(0f, 1000)
  override fun onDraw(cv: Canvas) {
    val cx = width / 2f; val cy = height * 0.42f; val R = min(width, height) * 0.30f
    val col = when (mode) { 3 -> 0xFFFF2BD6.toInt(); 2 -> 0xFF8FFFFF.toInt(); 1 -> 0xFF00F0FF.toInt(); else -> 0xFF1A7BFF.toInt() }
    p.style = Paint.Style.STROKE; p.shader = null; p.color = col; p.setShadowLayer(28f, 0f, 0f, col)
    p.strokeWidth = 7f; p.alpha = 255
    val r1 = R * 1.3f; cv.drawArc(RectF(cx - r1, cy - r1, cx + r1, cy + r1), t * 70, 80f + 280f * boot, false, p)   // blue ring grows
    p.strokeWidth = 4f; p.pathEffect = DashPathEffect(floatArrayOf(12f, 20f), t * 40); cv.drawCircle(cx, cy, R * 1.12f, p); p.pathEffect = null
    p.strokeWidth = 3f; val r3 = R * 0.95f; cv.drawArc(RectF(cx - r3, cy - r3, cx + r3, cy + r3), -t * 110, 110f, false, p); cv.drawArc(RectF(cx - r3, cy - r3, cx + r3, cy + r3), -t * 110 + 180, 110f, false, p)
    val a = 1f - boot
    if (a > 0.02f) { cv.save(); cv.rotate(t * 140, cx, cy); val path = Path(); val tr = R * 0.6f
      for (i in 0..2) { val ang = Math.toRadians(i * 120.0 - 90).toFloat(); val x = cx + tr * cos(ang); val y = cy + tr * sin(ang); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
      path.close(); p.strokeWidth = 6f; p.alpha = (255 * a).toInt(); cv.drawPath(path, p)
      p.style = Paint.Style.FILL; p.alpha = (200 * a).toInt(); cv.drawCircle(cx, cy, R * 0.16f, p); cv.restore() }
    if (boot > 0.02f) { val r = R * 0.66f * boot * (1f + 0.04f * sin(t * 2.2f) + level * 0.22f)
      p.style = Paint.Style.FILL; p.clearShadowLayer(); p.setShadowLayer(60f, 0f, 0f, col)
      p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.3f, intArrayOf(0xFFFFFFFF.toInt(), col, 0xFF050520.toInt()), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
      p.alpha = (255 * boot).toInt(); cv.drawCircle(cx, cy, r, p); p.shader = null }
    if (mode == 1 || mode == 2) { val k = t % 1.2f / 1.2f; p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = col; p.alpha = (140 * (1 - k)).toInt(); p.clearShadowLayer(); cv.drawCircle(cx, cy, R * (0.7f + 0.9f * k), p) }
  }
}

package com.jarvis.blind
import android.Manifest
import android.content.Intent
import android.location.LocationManager
import android.net.Uri
import android.provider.Settings
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.widget.*
import androidx.camera.view.PreviewView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

fun homePage(a: MainActivity): View {
  val l = col(a); val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); val part = if (hr < 12) "Morning," else if (hr < 17) "Afternoon," else "Evening,"
  val temp = txt(a, "…", 20f).apply { background = glass(a, 20); setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8)) }
  l.addView(temp, LinearLayout.LayoutParams(-2, -2))
  val g = SpannableStringBuilder("Good $part"); g.setSpan(ForegroundColorSpan(0xFF9AA0A6.toInt()), 0, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); g.setSpan(ForegroundColorSpan(C1), 5, g.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
  l.addView(txt(a, "", 38f).apply { text = g; setPadding(0, a.dp(14), 0, 0) })
  l.addView(txt(a, a.getSharedPreferences("j", 0).getString("name", "")!!.ifBlank { "Sir" }, 38f, 0xFF9AA0A6.toInt()))
  val now = System.currentTimeMillis(); val ev = a.events(now, now + 86400000L).size
  val bat = a.getSystemService(android.os.BatteryManager::class.java).getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
  l.addView(txt(a, SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date()) + "  •  $ev events  •  ${a.tasks().size} tasks  •  🔋$bat%", 14f, 0xFF9FD8FF.toInt()).apply { setPadding(0, a.dp(12), 0, 0) })
  l.addView(Space(a), LinearLayout.LayoutParams(-1, 0, 1f))
  l.addView(pill(a, "◎   Check Around Me") { a.show("lens") }); l.addView(pill(a, "▦   What's My Day Look Like") { a.run("calendar") })
  l.addView(pill(a, "✓   Prioritize My Tasks") { a.prioritize() }); l.addView(pill(a, "</>   Open Studio") { a.show("studio") })
  l.addView(txt(a, "●   Tap to speak, or say “Hey Jarvis”", 16f, 0xFF7FB8D0.toInt()).apply { setPadding(a.dp(8), a.dp(14), 0, 0); setOnClickListener { a.rv.performClick() } })
  Thread { try { val lm = a.getSystemService(LocationManager::class.java)
    val loc = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (e: SecurityException) { null }
    if (loc == null) a.runOnUiThread { temp.text = "Weather: no location" } else { val t = JSONObject(Ai.get("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current_weather=true")).getJSONObject("current_weather").getDouble("temperature")
      a.runOnUiThread { temp.text = "${t.toInt()}°C" } } } catch (e: Exception) { a.runOnUiThread { temp.text = "Weather offline" } } }.start()
  l.layoutParams = FrameLayout.LayoutParams(-1, -1); return l
}

fun discoverPage(a: MainActivity): View {
  val l = col(a); l.addView(txt(a, "Discover", 30f, CT, true))
  l.addView(pill(a, "◎   Check Around — identify & research objects") { a.show("lens") }); l.addView(pill(a, "</>   Studio — build websites, pages & visuals") { a.show("studio") })
  val q = edit(a, "Ask the AI tutor or research a topic…"); val out = txt(a, "", 15f).apply { setPadding(0, a.dp(12), 0, 0) }; l.addView(q, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.dp(14) })
  fun go(p: String) { if (q.text.isBlank()) { out.text = "Type a topic first." } else { out.text = "Thinking…"; Ai.ask(a, p + q.text) { out.text = it; a.say(it.take(300)) } } }
  val row = LinearLayout(a); row.addView(btn(a, "EXPLAIN") { go("Explain simply with an example: ") }); row.addView(btn(a, "QUIZ ME") { go("Write a 5 question practice quiz with answers about: ") })
  row.addView(btn(a, "WEB") { if (q.text.isNotBlank()) a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q.text.toString())))) }); l.addView(row); l.addView(out)
  return ScrollView(a).apply { addView(l) }
}

fun jarvisPage(a: MainActivity): View {
  val l = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(30), a.dp(14), a.dp(150)) }
  l.addView(a.rv, LinearLayout.LayoutParams(-1, 0, 1.1f)); val log = txt(a, a.chat.toString(), 15f); a.logTv = log
  l.addView(ScrollView(a).apply { addView(log); post { fullScroll(View.FOCUS_DOWN) } }, LinearLayout.LayoutParams(-1, 0, 1f))
  val row = LinearLayout(a); val inp = edit(a, "Type to Jarvis…"); row.addView(inp, LinearLayout.LayoutParams(0, -2, 1f))
  row.addView(btn(a, "SEND") { val s = inp.text.toString().trim(); if (s.isNotEmpty()) { inp.setText(""); a.run(s.lowercase()) } }.apply { layoutParams = LinearLayout.LayoutParams(a.dp(90), -2) }); l.addView(row); return l
}

fun dayPage(a: MainActivity): View {
  val l = col(a); l.addView(txt(a, "My Day", 30f, CT, true)); val now = System.currentTimeMillis()
  val ev = a.events(now, now + 86400000L); val f = SimpleDateFormat("h:mm a", Locale.getDefault())
  l.addView(txt(a, if (ev.isEmpty()) "Nothing on your calendar for the next 24 hours." else ev.take(6).joinToString("\n") { f.format(Date(it.second)) + "  " + it.first }, 15f, 0xFF9FD8FF.toInt()).apply { setPadding(0, a.dp(8), 0, a.dp(12)) })
  val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
  fun draw() { box.removeAllViews(); val t = a.tasks(); if (t.isEmpty()) box.addView(txt(a, "No tasks. Add one below or say “add task …”.", 15f))
    t.forEachIndexed { i, s -> box.addView(pill(a, "☐   $s") { t.removeAt(i); a.saveTasks(t); draw() }) } }
  draw(); l.addView(box); val inp = edit(a, "New task or reminder…"); l.addView(inp, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.dp(10) })
  l.addView(LinearLayout(a).apply { addView(btn(a, "ADD TASK") { val s = inp.text.toString().trim(); if (s.isNotEmpty()) { val t = a.tasks(); t.add(s); a.saveTasks(t); inp.setText(""); draw() } })
    addView(btn(a, "PRIORITIZE") { a.prioritize() }) }); l.addView(txt(a, "Tap a task to complete it.", 12f, 0xFF7FB8D0.toInt())); return ScrollView(a).apply { addView(l) }
}

fun profilePage(a: MainActivity): View {
  val l = col(a); val p = a.getSharedPreferences("j", 0); l.addView(txt(a, "Profile", 30f, CT, true))
  val name = edit(a, "Your name").apply { setText(p.getString("name", "")) }; l.addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.dp(10) })
  val keys = try { Ai.prefs(a) } catch (e: Exception) { null }; val fs = HashMap<String, EditText>()
  for ((id, lb) in listOf("openai" to "OpenAI (reasoning)", "claude" to "Claude (code & documents)", "gemini" to "Gemini (research)")) {
    l.addView(txt(a, "$lb — " + if (keys?.getString(id, "").isNullOrBlank()) "not connected" else "connected ✓", 14f, 0xFF9FD8FF.toInt()).apply { setPadding(0, a.dp(12), 0, a.dp(4)) })
    val e = edit(a, "API key (kept encrypted on this phone)").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }; fs[id] = e; l.addView(e) }
  val order = listOf("openai", "claude", "gemini")
  l.addView(pill(a, "Preferred AI: ${p.getString("prov", "openai")}  (tap to switch)") { p.edit().putString("prov", order[(order.indexOf(p.getString("prov", "openai")) + 1) % 3]).apply(); a.show("profile") })
  l.addView(pill(a, "💾   Save") { p.edit().putString("name", name.text.toString().trim()).apply(); fs.forEach { (k, v) -> if (v.text.isNotBlank()) keys?.edit()?.putString(k, v.text.toString().trim())?.apply() }; a.say("Saved."); a.show("profile") })
  val notes = (p.getString("n", "") ?: "").split("|").filter { it.isNotBlank() }
  l.addView(txt(a, "Memory: ${notes.size} saved notes", 14f, 0xFF9FD8FF.toInt()).apply { setPadding(0, a.dp(12), 0, 0) })
  l.addView(pill(a, "🗑   Delete all notes & memory") { p.edit().remove("n").apply(); a.say("Memory cleared."); a.show("profile") })
  l.addView(pill(a, "🔐   App permissions") { a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.packageName))) })
  l.addView(pill(a, "♿   Accessibility service (optional)") { a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
  l.addView(pill(a, "⏻   Turn Jarvis off") { a.finishAffinity() }); return ScrollView(a).apply { addView(l) }
}

fun lensPage(a: MainActivity): View {
  val f = FrameLayout(a); val pv = PreviewView(a); a.pv = pv; f.addView(pv, FrameLayout.LayoutParams(-1, -1))
  val out = txt(a, "Point the camera at an object, then tap SCAN. You can also say “what is this”.", 15f).apply { setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }; a.lensOut = out
  val sv = ScrollView(a).apply { addView(out); background = glass(a, 20); setBackgroundColor(0xCC02030A.toInt()) }
  val row = LinearLayout(a); row.addView(btn(a, "SCAN") { a.scan() }); row.addView(btn(a, "LIVE") { a.startCheck() }); row.addView(btn(a, "STOP") { a.stopCheck() })
  row.addView(btn(a, "WEB") { if (a.lastLabel.isNotBlank()) a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.lastLabel)))) })
  val panel = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; addView(sv, LinearLayout.LayoutParams(-1, a.dp(170))); addView(row) }
  f.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(a.dp(14), 0, a.dp(14), a.dp(150)) })
  if (a.checkSelfPermission(Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) pv.post { a.bindCam(false) } else a.requestPermissions(arrayOf(Manifest.permission.CAMERA), 2)
  return f
}

object Studio { val tabs = mutableListOf("<body style='background:#02030a;color:#0ef;font-family:sans-serif;text-align:center;padding-top:25vh'><h1>Jarvis Studio</h1><p>Edit the code, or describe a site and tap AI BUILD</p></body>"); var cur = 0 }
fun studioPage(a: MainActivity): View {
  val l = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(12), a.dp(56), a.dp(12), a.dp(120)) }
  val strip = LinearLayout(a); val web = WebView(a).apply { settings.javaScriptEnabled = true; settings.allowFileAccess = false; settings.allowContentAccess = false; setBackgroundColor(0xFF000000.toInt()) }
  val code = edit(a, "HTML / CSS / JS").apply { gravity = Gravity.TOP; typeface = android.graphics.Typeface.MONOSPACE; textSize = 12f; setText(Studio.tabs[Studio.cur]) }
  val prompt = edit(a, "Describe a website, page or visual for the AI to build")
  fun render() { Studio.tabs[Studio.cur] = code.text.toString(); web.loadDataWithBaseURL(null, Studio.tabs[Studio.cur], "text/html", "utf-8", null) }
  fun tabs() { strip.removeAllViews(); for (i in Studio.tabs.indices) strip.addView(txt(a, " ${i + 1} ", 18f, if (i == Studio.cur) C1 else CT, true).apply { background = glass(a, 12); setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8))
      setOnClickListener { Studio.tabs[Studio.cur] = code.text.toString(); Studio.cur = i; code.setText(Studio.tabs[i]); tabs(); render() } })
    if (Studio.tabs.size < 6) strip.addView(txt(a, " + ", 18f, CT, true).apply { background = glass(a, 12); setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8))
      setOnClickListener { Studio.tabs[Studio.cur] = code.text.toString(); Studio.tabs.add("<body style='background:#000;color:#fff'><h1>New tab</h1></body>"); Studio.cur = Studio.tabs.size - 1; code.setText(Studio.tabs[Studio.cur]); tabs(); render() } }) }
  tabs(); l.addView(HorizontalScrollView(a).apply { addView(strip) }); l.addView(web, LinearLayout.LayoutParams(-1, 0, 1f)); l.addView(code, LinearLayout.LayoutParams(-1, 0, 1f)); l.addView(prompt)
  l.addView(LinearLayout(a).apply { addView(btn(a, "RUN") { render() })
    addView(btn(a, "AI BUILD") { val q = prompt.text.toString(); if (q.isNotBlank()) { a.say("Building."); Ai.ask(a, "Create ONE self-contained HTML file (inline CSS and JS, no external files, mobile friendly, dark modern design) for: $q. Reply with code only.") { r ->
      code.setText(r.replace(Regex("```[a-zA-Z]*"), "").trim()); render(); a.say("Done. Check the preview.") } } }) })
  render(); return l
}

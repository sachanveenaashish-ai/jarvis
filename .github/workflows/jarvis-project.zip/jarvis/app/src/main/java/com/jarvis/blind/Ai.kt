package com.jarvis.blind
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
object Ai {   // model router: your preferred provider first, then the others as fallback. Keys live encrypted on this phone only.
  fun prefs(c: Context) = EncryptedSharedPreferences.create(c, "keys", MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
  fun has(c: Context) = try { listOf("openai", "claude", "gemini").any { !prefs(c).getString(it, "").isNullOrBlank() } } catch (e: Exception) { false }
  fun ask(c: Context, q: String, cb: (String) -> Unit) {
    val pref = c.getSharedPreferences("j", 0).getString("prov", "openai")!!; val order = listOf(pref) + listOf("openai", "claude", "gemini").filter { it != pref }
    Thread { var out = "No AI key is set. Add one in Profile."
      try { val p = prefs(c); for (n in order) { val k = p.getString(n, "") ?: ""; if (k.isBlank()) continue
        try { out = call(n, k, q); break } catch (e: Exception) { out = "The $n request failed: ${e.message}" } } } catch (e: Exception) { out = "Secure storage error." }
      Handler(Looper.getMainLooper()).post { cb(out) } }.start() }
  private fun msgs(q: String) = JSONArray().put(JSONObject().put("role", "user").put("content", q))
  private fun call(n: String, k: String, q: String): String {
    val (url, hdr, body) = when (n) {
      "openai" -> Triple("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to "Bearer $k"), JSONObject().put("model", "gpt-4o-mini").put("messages", msgs(q)).toString())
      "claude" -> Triple("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to k, "anthropic-version" to "2023-06-01"), JSONObject().put("model", "claude-sonnet-4-6").put("max_tokens", 2000).put("messages", msgs(q)).toString())
      else -> Triple("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent", mapOf("x-goog-api-key" to k),
        JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", q))))).toString()) }
    val cn = URL(url).openConnection() as HttpURLConnection; cn.requestMethod = "POST"; cn.doOutput = true; cn.connectTimeout = 15000; cn.readTimeout = 60000
    cn.setRequestProperty("Content-Type", "application/json"); hdr.forEach { (a, b) -> cn.setRequestProperty(a, b) }; cn.outputStream.use { it.write(body.toByteArray()) }
    if (cn.responseCode >= 400) throw Exception("HTTP ${cn.responseCode}")
    val j = JSONObject(cn.inputStream.bufferedReader().readText())
    return when (n) { "openai" -> j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
      "claude" -> j.getJSONArray("content").getJSONObject(0).getString("text")
      else -> j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text") } }
  fun get(u: String): String { val cn = URL(u).openConnection() as HttpURLConnection; cn.connectTimeout = 10000; cn.readTimeout = 15000; cn.setRequestProperty("User-Agent", "JarvisApp/1.0")
    return cn.inputStream.bufferedReader().readText() }
}

package com.jarvis.blind
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
class JarvisAccessibility : AccessibilityService() {
  companion object { var inst: JarvisAccessibility? = null; val on get() = inst != null }
  override fun onServiceConnected() { inst = this }
  override fun onDestroy() { inst = null; super.onDestroy() }
  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}
  fun act(a: Int) = performGlobalAction(a)
  fun readScreen(): String { val sb = StringBuilder(); fun w(n: AccessibilityNodeInfo?) { n ?: return
      n.text?.let { sb.append(it).append(". ") } ?: n.contentDescription?.let { sb.append(it).append(". ") }
      for (i in 0 until n.childCount) w(n.getChild(i)) }
    w(rootInActiveWindow); return sb.toString().ifBlank { "I cannot read anything on this screen." }.take(1500) }
}

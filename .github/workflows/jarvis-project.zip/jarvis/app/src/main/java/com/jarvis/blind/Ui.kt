package com.jarvis.blind
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.*
const val C1 = 0xFF00E5FF.toInt(); const val CT = 0xFFEAF6FF.toInt()
fun Context.dp(x: Int) = (x * resources.displayMetrics.density).toInt()
fun glass(c: Context, r: Int = 22) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x33FFFFFF, 0x0FFFFFFF)).apply { cornerRadius = c.dp(r).toFloat(); setStroke(c.dp(1), 0x33FFFFFF) }
fun txt(c: Context, s: String, sz: Float = 16f, col: Int = CT, bold: Boolean = false) = TextView(c).apply { text = s; textSize = sz; setTextColor(col); if (bold) setTypeface(typeface, Typeface.BOLD) }
fun pill(c: Context, s: String, f: () -> Unit) = txt(c, s, 16f).apply { background = glass(c, 28); setPadding(c.dp(20), c.dp(16), c.dp(20), c.dp(16)); contentDescription = s
  setOnClickListener { f() }; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, c.dp(6), 0, c.dp(6)) } }
fun col(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(c.dp(20), c.dp(64), c.dp(20), c.dp(120)) }
fun edit(c: Context, hint: String) = EditText(c).apply { this.hint = hint; setHintTextColor(0x88FFFFFF.toInt()); setTextColor(CT); background = glass(c, 16); setPadding(c.dp(16), c.dp(12), c.dp(16), c.dp(12)) }
fun btn(c: Context, s: String, f: () -> Unit) = txt(c, s, 14f, 0xFF02030A.toInt(), true).apply { gravity = android.view.Gravity.CENTER; contentDescription = s
  background = GradientDrawable().apply { cornerRadius = c.dp(22).toFloat(); setColor(C1) }; setPadding(c.dp(12), c.dp(12), c.dp(12), c.dp(12)); setOnClickListener { f() }
  layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(c.dp(4), c.dp(4), c.dp(4), c.dp(4)) } }

package com.jarvis.blind
import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.AlertDialog
import androidx.camera.view.PreviewView
import org.json.JSONObject
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.SmsManager
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
  lateinit var rv: ReactorView; lateinit var tv: TextView; lateinit var host: FrameLayout; lateinit var nav: LinearLayout; private lateinit var tts: TextToSpeech
  private var sr: SpeechRecognizer? = null; private val h = Handler(Looper.getMainLooper())
  private var active = false; private var awake = false; private var awakeUntil = 0L; private var ttsReady = false
  @Volatile private var speaking = false; @Volatile private var endAt = 0L; @Volatile private var rms = 0f
  private var checking = false; private var cam: Camera? = null; private var prev: ByteArray? = null
  private var lastRun = 0L; private var lastMove = 0L; private val said = HashMap<String, Long>()
  private var lastText = ""; private var pendingSms: Pair<String, String>? = null; private var pendingAcc = false
  var pv: PreviewView? = null; var cap: ImageCapture? = null; var lensOut: TextView? = null; var logTv: TextView? = null; var lastLabel = ""; val chat = StringBuilder()
  private val ex = Executors.newSingleThreadExecutor(); val labeler by lazy { ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS) }
  private val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALENDAR,
    Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.ACCESS_FINE_LOCATION)
  private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
  private val tick = object : Runnable { override fun run() {
    rv.level = if (speaking) 0.3f + Math.random().toFloat() * 0.7f else Math.min(1f, Math.max(0f, rms) / 10f)
    rv.mode = if (speaking) 2 else if (checking) 3 else if (awake) 1 else 0
    if (awake && !speaking && !checking && System.currentTimeMillis() > awakeUntil) { awake = false; rv.sleep() }
    h.postDelayed(this, 70) } }

  override fun onCreate(b: Bundle?) {
    super.onCreate(b); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    rv = ReactorView(this); rv.contentDescription = "Jarvis orb. Double tap to wake."
    rv.setOnClickListener { wakeUp(); awake = true; awakeUntil = System.currentTimeMillis() + 15000; h.postDelayed({ say("Yes sir, what's the task?") }, 1500) }
    tv = txt(this, "Say hey Jarvis", 15f, 0xFFBFEFFF.toInt()).apply { background = glass(this@MainActivity, 18); setPadding(dp(16), dp(10), dp(16), dp(10)); maxLines = 3 }
    host = FrameLayout(this); nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = glass(this@MainActivity, 30); setPadding(dp(6), dp(8), dp(6), dp(8)) }
    for ((id, lb) in listOf("home" to "⌂\nHome", "discover" to "✦\nDiscover", "jarvis" to "◉\nJarvis", "day" to "☰\nMy Day", "profile" to "☺\nProfile"))
      nav.addView(txt(this, lb, 12f).apply { gravity = Gravity.CENTER; tag = id; contentDescription = lb.replace("\n", " "); setOnClickListener { show(id) } }, LinearLayout.LayoutParams(0, -2, 1f))
    val root = FrameLayout(this).apply { setBackgroundColor(0xFF02030A.toInt()); addView(host, FrameLayout.LayoutParams(-1, -1))
      addView(tv, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(20), 0, dp(20), dp(104)) })
      addView(nav, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(16), 0, dp(16), dp(20)) }) }
    setContentView(root); show("home"); tts = TextToSpeech(this, this); h.post(tick)
    if (!micOk()) requestPermissions(perms, 1)
  }
  override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(c, p, r); if (active) listen() }
  override fun onResume() { super.onResume(); active = true; if (micOk()) listen() }   // mic only while the app is open
  override fun onPause() { super.onPause(); active = false; sr?.destroy(); sr = null; checking = false; prev = null; tts.stop() }
  override fun onDestroy() { h.removeCallbacksAndMessages(null); tts.shutdown(); super.onDestroy() }
  override fun onInit(s: Int) { ttsReady = true
    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
      override fun onStart(id: String?) { speaking = true }
      override fun onDone(id: String?) { speaking = false; endAt = System.currentTimeMillis() }
      @Deprecated("x") override fun onError(id: String?) { speaking = false; endAt = System.currentTimeMillis() } })
    say("Systems online. Say hey Jarvis.") }
  fun say(t: String) { lastText = t; tv.text = t; chat.append("Jarvis: $t\n\n"); logTv?.text = chat; if (ttsReady) tts.speak(t, TextToSpeech.QUEUE_ADD, null, "j") }
  fun wakeUp() { if (rv.boot < 0.5f) rv.wake() }

  // ---------- listening ----------
  private fun listen() {
    if (!active || !micOk() || !SpeechRecognizer.isRecognitionAvailable(this)) return
    sr?.destroy(); val s = SpeechRecognizer.createSpeechRecognizer(this); sr = s
    s.setRecognitionListener(object : RecognitionListener {
      override fun onResults(r: Bundle?) { r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard(it.lowercase()) }; again() }
      override fun onError(e: Int) { again() }
      override fun onRmsChanged(v: Float) { rms = v }
      override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}; override fun onBufferReceived(b: ByteArray?) {}
      override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {} })
    s.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
  }
  private fun again() { h.postDelayed({ listen() }, 450) }
  private fun heard(t: String) {
    if (speaking || System.currentTimeMillis() - endAt < 1800) return
    val m = Regex("(hey |ok |okay )?(jarvis|chevy)").find(t)
    if (m != null) { val c = t.substring(m.range.last + 1).trim(' ', ',', '.'); wakeUp(); awake = true; awakeUntil = System.currentTimeMillis() + 12000
      if (c.isEmpty()) h.postDelayed({ say("Yes sir, what's the task?") }, 1500) else run(c) }
    else if (awake) run(t.trim())
  }

  // ---------- commands ----------
  private fun need(): JarvisAccessibility? { val a = JarvisAccessibility.inst
    if (a == null) { pendingAcc = true; say("That needs the accessibility service. Do you want to turn it on for better functioning? Say yes or no.")
      AlertDialog.Builder(this).setTitle("Turn on accessibility?").setMessage("For screen reading and Back/Home by voice. It never records or sends your screen.")
        .setPositiveButton("Yes") { _, _ -> pendingAcc = false; startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }.setNegativeButton("No") { _, _ -> pendingAcc = false }.show() }
    return a }
  private fun yes(c: String) = Regex("\\b(yes|yeah|yep|send|confirm|sure|ok)\\b").containsMatchIn(c)
  fun run(c: String) {
    awakeUntil = System.currentTimeMillis() + 10000; chat.append("You: $c\n")
    if (pendingAcc) { pendingAcc = false; if (yes(c)) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) else say("Okay, I will not."); return }
    pendingSms?.let { pendingSms = null; if (yes(c)) try { SmsManager.getDefault().sendTextMessage(it.first, null, it.second, null, null); say("Message sent.") } catch (e: Exception) { say("I could not send it.") } else say("Cancelled."); return }
    when {
      Regex("take a (picture|photo)|click a picture|what is this|identify|scan this").containsMatchIn(c) -> { show("lens"); h.postDelayed({ scan() }, 1800) }
      c.contains("studio") -> show("studio")
      c.startsWith("add task") || c.startsWith("add to do") -> { val t = tasks(); t.add(c.substringAfter("task", c.substringAfter("do")).trim()); saveTasks(t); say("Task added.") }
      c.contains("my tasks") || c.contains("to do list") -> prioritize(false)
      Regex("^(exit|quit|shut ?down|goodbye|close|turn off jarvis)").containsMatchIn(c) -> { say("Shutting down. Goodbye sir."); h.postDelayed({ finishAffinity() }, 2500) }
      c.contains("help") || c.contains("what can you do") -> say("I can check around you nonstop, read the screen, open apps, call and text, play music, set timers and alarms, read your calendar and birthdays, take notes, tell time, date, battery and location, control volume and flashlight, do math, navigate, search the web, flip coins, tell jokes, and call for emergency help.")
      Regex("stop (the )?(check|scan)").containsMatchIn(c) -> stopCheck()
      Regex("check|look|scan|around me|what.*front").containsMatchIn(c) -> { show("lens"); h.postDelayed({ startCheck() }, 1500) }
      c.contains("repeat") -> say(lastText)
      c.contains("stop") || c.contains("quiet") -> tts.stop()
      c.contains("read") && c.contains("screen") -> need()?.let { say(it.readScreen()) }
      c.contains("go back") -> need()?.act(AccessibilityService.GLOBAL_ACTION_BACK)
      c.contains("go home") -> need()?.act(AccessibilityService.GLOBAL_ACTION_HOME)
      c.contains("recent apps") -> need()?.act(AccessibilityService.GLOBAL_ACTION_RECENTS)
      c.contains("time") -> say("It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
      c.contains("date") || c.contains("day is it") -> say("Today is " + SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()))
      c.contains("battery") -> say("Battery is ${getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent.")
      c.contains("where am i") || c.contains("my location") -> loc()
      c.contains("flashlight") || c.contains("torch") -> torch(!c.contains("off"))
      c.contains("volume") -> { val up = !c.contains("down") && !c.contains("lower"); getSystemService(AudioManager::class.java).adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); say("Volume ${if (up) "up" else "down"}.") }
      c.contains("emergency") || c.contains("sos") -> { say("Calling emergency."); call(contact("emergency") ?: "112") }
      c.startsWith("call") -> { val n = c.removePrefix("call").removePrefix(" my").trim(); contact(n)?.let { say("Calling $n"); call(it) } ?: say("I could not find $n in your contacts.") }
      Regex("message to").containsMatchIn(c) -> { val m = Regex("message to (?:my )?(\\w+)\\s*(?:that|saying)?\\s*(.*)").find(c)!!
        val num = contact(m.groupValues[1]); if (num == null) say("I could not find ${m.groupValues[1]}.") else { pendingSms = num to m.groupValues[2]; say("Send to ${m.groupValues[1]}: ${m.groupValues[2]}. Say yes to send.") } }
      c.contains("birthday") -> birthday()
      c.contains("calendar") || c.contains("schedule") || c.contains("agenda") -> today()
      c.contains("alarm") -> alarm(c)
      c.contains("timer") -> timer(c)
      c.startsWith("play") || c.contains("song") || c.contains("music") -> { val q = c.substringAfter("play", "").trim().ifEmpty { "popular songs" }; say("Playing $q"); go(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(q)))) }
      c.startsWith("open") -> openApp(c.removePrefix("open").trim())
      c.contains("navigate") || c.contains("directions") -> { val q = c.substringAfter(" to ", c.substringAfter("navigate")).trim(); say("Starting navigation."); go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q)))) }
      c.contains("map") || c.contains("nearby") || c.contains("find a ") -> { say("Opening maps."); go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(c.substringAfter("for ", c.substringAfter("find ")))))) }
      c.contains("weather") -> { say("Opening the weather."); go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=weather+today"))) }
      c.contains("wifi") || c.contains("wi-fi") -> go(Intent(Settings.ACTION_WIFI_SETTINGS))
      c.contains("bluetooth") -> go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
      c.startsWith("note") || c.startsWith("remember") || c.contains("take a note") -> { val n = c.substringAfter("that", c.substringAfter("note")).trim(); val p = getSharedPreferences("j", 0); p.edit().putString("n", (p.getString("n", "") ?: "") + n + "|").apply(); say("Noted.") }
      c.contains("my notes") || c.contains("read notes") -> say((getSharedPreferences("j", 0).getString("n", "") ?: "").split("|").filter { it.isNotBlank() }.joinToString(". ").ifEmpty { "You have no notes." })
      c.contains("coin") -> say(if (Math.random() < .5) "Heads." else "Tails.")
      c.contains("dice") || c.contains("roll") -> say("You rolled a ${(1..6).random()}.")
      c.contains("joke") -> say(listOf("Why did the phone go to the doctor? It lost its signal.", "I told my computer I needed a break. It said no problem, it will go to sleep.", "Why was the robot calm? It had nerves of steel.").random())
      c.contains("who are you") -> say("I am Jarvis, your personal assistant, at your service.")
      c.contains("how are you") -> say("All systems running at full power, sir.")
      c.contains("thank") -> say("Always a pleasure, sir.")
      Regex("(\\d+(?:\\.\\d+)?)\\s*(plus|minus|times|multiplied by|divided by|x)\\s*(\\d+(?:\\.\\d+)?)").find(c)?.let { m -> val a = m.groupValues[1].toDouble(); val b = m.groupValues[3].toDouble(); val o = m.groupValues[2]
        say("The answer is " + (if (o == "plus") a + b else if (o == "minus") a - b else if (o.startsWith("divided")) a / b else a * b).let { if (it % 1.0 == 0.0) it.toLong().toString() else "%.4f".format(it) }); true } == true -> {}
      Ai.has(this) && Regex("^(who|what|why|how|explain|translate|write|summari)").containsMatchIn(c) -> ai(c)
      c.contains("search") || c.startsWith("who") || c.startsWith("what") || c.startsWith("how") -> { say("Searching."); go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(c)))) }
      else -> ai(c)
    }
  }
  private fun go(i: Intent) = try { startActivity(i) } catch (e: Exception) { say("I could not open that.") }
  @SuppressLint("MissingPermission") private fun call(n: String) = go(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")))
  private fun contact(name: String): String? = try { contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { if (it.moveToFirst()) it.getString(0) else null } } catch (e: Exception) { null }
  private fun openApp(n: String) { val pm = packageManager; val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    val a = l.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
    if (a != null) { say("Opening $n"); go(pm.getLaunchIntentForPackage(a.activityInfo.packageName)!!) } else say("I could not find an app called $n.") }
  private fun timer(c: String) { val m = Regex("(\\d+)\\s*(second|minute|hour)").find(c) ?: return say("How long should the timer be?")
    val n = m.groupValues[1].toLong(); val ms = n * when (m.groupValues[2]) { "second" -> 1000L; "minute" -> 60000L; else -> 3600000L }
    h.postDelayed({ say("Sir, your timer is done.") }, ms); say("Timer set for $n ${m.groupValues[2]}s.") }
  private fun alarm(c: String) { val m = Regex("(\\d{1,2})(?::| )?(\\d{2})? ?(am|pm|a m|p m)?").find(c.substringAfter("alarm")) ?: return say("What time should the alarm be?")
    var hr = m.groupValues[1].toInt(); val mi = m.groupValues[2].ifEmpty { "0" }.toInt(); val pm = m.groupValues[3].startsWith("p"); if (pm && hr < 12) hr += 12; if (!pm && m.groupValues[3].startsWith("a") && hr == 12) hr = 0
    say("Setting an alarm for $hr:${"%02d".format(mi)}."); go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hr).putExtra(AlarmClock.EXTRA_MINUTES, mi).putExtra(AlarmClock.EXTRA_SKIP_UI, true)) }
  fun events(from: Long, to: Long): List<Pair<String, Long>> = try { val b = CalendarContract.Instances.CONTENT_URI.buildUpon(); ContentUris.appendId(b, from); ContentUris.appendId(b, to)
    contentResolver.query(b.build(), arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN), null, null, "begin ASC")?.use { c -> val o = ArrayList<Pair<String, Long>>(); while (c.moveToNext()) o.add((c.getString(0) ?: "event") to c.getLong(1)); o } ?: emptyList() } catch (e: Exception) { emptyList() }
  private fun today() { val s = System.currentTimeMillis(); val e = events(s, s + 86400000L)
    say(if (e.isEmpty()) "Nothing on your calendar in the next 24 hours." else e.take(5).joinToString(". ") { it.first + " at " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(it.second)) }) }
  private fun birthday() { val s = System.currentTimeMillis(); val e = events(s, s + 366L * 86400000L).firstOrNull { it.first.lowercase().contains("birthday") }
    say(if (e == null) "I could not find a birthday on your calendar." else e.first + " is on " + SimpleDateFormat("MMMM d", Locale.getDefault()).format(Date(e.second)) + ".") }
  @SuppressLint("MissingPermission") private fun loc() { val l = getSystemService(LocationManager::class.java).getLastKnownLocation(LocationManager.GPS_PROVIDER)
    say(if (l == null) "I cannot get your location yet." else "Latitude ${"%.4f".format(l.latitude)}, longitude ${"%.4f".format(l.longitude)}.") }
  private fun torch(on: Boolean) { if (cam != null) cam?.cameraControl?.enableTorch(on) else try { val cm = getSystemService(CameraManager::class.java); cm.setTorchMode(cm.cameraIdList[0], on) } catch (e: Exception) { return say("No flashlight.") }
    say(if (on) "Flashlight on." else "Flashlight off.") }

  // ---------- continuous check: runs until you say "stop check" ----------
  fun startCheck() {
    if (checking) return say("Already checking."); if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return say("Camera permission is needed.")
    checking = true; say("Check started. I will keep watching until you say stop check."); bindCam(true) }
  fun stopCheck() { checking = false; prev = null; bindCam(false); say("Check stopped.") }
  fun bindCam(live: Boolean) { val f = ProcessCameraProvider.getInstance(this); f.addListener({ val p = f.get(); p.unbindAll(); if (pv == null && !live) { cam = null; return@addListener }
    val u = ArrayList<UseCase>(); pv?.let { v -> u.add(Preview.Builder().build().also { it.setSurfaceProvider(v.surfaceProvider) }) }
    val ic = ImageCapture.Builder().build(); cap = ic; u.add(ic)
    if (live) { val a = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build(); a.setAnalyzer(ex) { analyze(it) }; u.add(a) }
    cam = p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, *u.toTypedArray()) }, ContextCompat.getMainExecutor(this)) }
  fun scan() { val c = cap ?: return say("The camera is not ready. Open Check Around first."); say("Analyzing. Hold still."); lensOut?.text = "Analyzing…"
    c.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
      @androidx.annotation.OptIn(ExperimentalGetImage::class) override fun onCaptureSuccess(img: ImageProxy) { val m = img.image; if (m == null) { img.close(); return }
        labeler.process(InputImage.fromMediaImage(m, img.imageInfo.rotationDegrees)).addOnSuccessListener { ls -> research(ls.filter { it.confidence > 0.5f }.take(3).map { it.text to it.confidence }) }.addOnCompleteListener { img.close() } }
      override fun onError(e: ImageCaptureException) { say("I could not take the picture.") } }) }
  fun research(l: List<Pair<String, Float>>) { if (l.isEmpty()) { lensOut?.text = "I could not identify it. Try a closer, brighter shot."; return say("I could not identify that.") }
    lastLabel = l[0].first; val det = l.joinToString { "${it.first} (${(it.second * 100).toInt()}%)" }; lensOut?.text = "Detected: $det\nResearching…"; say("This looks like ${l[0].first}. Researching.")
    Thread { val info = try { JSONObject(Ai.get("https://en.wikipedia.org/api/rest_v1/page/summary/" + Uri.encode(l[0].first.replace(' ', '_')))).getString("extract") } catch (e: Exception) { "" }
      runOnUiThread { if (info.isBlank()) { lensOut?.text = "Detected: $det\nNo encyclopedia article found. Tap WEB."; say("I found no article. Tap web to search.") } else { lensOut?.text = "Detected: $det\n\n$info"; say(info.split(". ").take(2).joinToString(". ")) } } }.start() }
  fun tasks(): MutableList<String> = (getSharedPreferences("j", 0).getString("t", "") ?: "").split("|").filter { it.isNotBlank() }.toMutableList()
  fun saveTasks(l: List<String>) { getSharedPreferences("j", 0).edit().putString("t", l.joinToString("|")).apply() }
  fun prioritize(useAi: Boolean = true) { val t = tasks(); if (t.isEmpty()) return say("You have no tasks. Say add task, then the task.")
    if (useAi && Ai.has(this)) ai("Prioritize these tasks for today in order, one short reason each: " + t.joinToString("; ")) else say("Your tasks: " + t.joinToString(". ")) }
  fun ai(q: String) { if (!Ai.has(this)) return say("Sorry sir, I did not understand. Say help, or add an AI key in Profile for open questions."); say("Thinking."); Ai.ask(this, q) { say(it) } }
  fun show(id: String) { if (id != "lens") { pv = null; lensOut = null; if (cam != null) { checking = false; prev = null; try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (e: Exception) {}; cam = null } }
    logTv = null; host.removeAllViews()
    host.addView(when (id) { "discover" -> discoverPage(this); "jarvis" -> jarvisPage(this); "day" -> dayPage(this); "profile" -> profilePage(this); "lens" -> lensPage(this); "studio" -> studioPage(this); else -> homePage(this) })
    for (i in 0 until nav.childCount) { val t = nav.getChildAt(i) as TextView; t.setTextColor(if (t.tag == id) C1 else CT) } }

  @androidx.annotation.OptIn(ExperimentalGetImage::class)
  private fun analyze(img: ImageProxy) {
    val now = System.currentTimeMillis(); if (!checking || now - lastRun < 1200) { img.close(); return }; lastRun = now
    val y = img.planes[0].buffer; val w = img.width; val hh = img.height; val g = ByteArray(16 * 12)
    for (r in 0 until 12) for (c in 0 until 16) g[r * 16 + c] = y.get((r * hh / 12) * img.planes[0].rowStride + c * w / 16)
    val pv = prev; prev = g
    if (pv != null) { var n = 0; var sx = 0; for (i in g.indices) if (Math.abs((g[i].toInt() and 255) - (pv[i].toInt() and 255)) > 35) { n++; sx += i % 16 }
      if (n in 2..140 && now - lastMove > 6000) { lastMove = now; runOnUiThread { say("Something alive is moving ${side(sx / n / 16f)}.") } }
      else if (n > 150 && now - lastMove > 8000) { lastMove = now; runOnUiThread { say("The phone is shaking, I cannot judge movement.") } } }
    val m = img.image; if (m == null) { img.close(); return }
    labeler.process(InputImage.fromMediaImage(m, img.imageInfo.rotationDegrees)).addOnSuccessListener { ls ->
      ls.filter { it.confidence > 0.7f }.take(2).forEach { if (now - (said[it.text] ?: 0) > 25000) { said[it.text] = now; say("I see ${it.text}.") } } }.addOnCompleteListener { img.close() }
  }
  private fun side(x: Float) = if (x < .33f) "on your left" else if (x > .66f) "on your right" else "straight ahead"
}
